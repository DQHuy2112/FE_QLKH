'use client';

import { useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Header from '@/components/layout/Header';
import Sidebar from '@/components/layout/Sidebar';

interface ProductItem {
    id: number;
    name: string;
    code: string;
    unit: string;
    price: string;
    quantity: string;
    discount: string;
    total: string;
}

export default function EditExportReceipt() {
    const params = useParams();
    const router = useRouter();

    const [products, setProducts] = useState<ProductItem[]>([
        { id: 1, name: 'ĐT Samsung Galaxy Z', code: 'XXXXX', unit: 'Cái', price: '30.000.000', quantity: '10', discount: '5%', total: '285.000.000' },
        { id: 2, name: 'ĐT Xiaomi Redmi 10', code: 'XXXXX', unit: 'Cái', price: '3.998.000', quantity: '10', discount: '', total: '39.980.000' },
        { id: 3, name: 'ĐT Iphone 13 Promax', code: 'XXXXX', unit: 'Cái', price: '40.000.000', quantity: '5', discount: '5%', total: '78.154.168' },
        { id: 4, name: 'Tai nghe Xiaomi', code: 'XXXXX', unit: 'Cái', price: '200.000', quantity: '4', discount: '', total: '800.000' },
        { id: 5, name: 'Tai nghe Oppo Renco', code: 'XXXXX', unit: 'Cái', price: '790.000', quantity: '', discount: '', total: '' },
    ]);

    const calculateTotal = () => {
        return products.reduce((sum, item) => {
            const total = item.total ? parseInt(item.total.replace(/\./g, '')) : 0;
            return sum + total;
        }, 0).toLocaleString('vi-VN');
    };

    const deleteProduct = (id: number) => {
        setProducts(products.filter(p => p.id !== id));
    };

    return (
        <div className="min-h-screen">
            <Header />
            <Sidebar />

            <main className="ml-[377px] mt-[113px] p-6 pr-12">
                {/* Action Buttons */}
                <div className="flex gap-4 mb-6">
                    <button className="px-6 py-2.5 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white rounded-lg font-bold text-sm shadow-lg transition-all">
                        + Thêm hàng<br />từ hệ thống
                    </button>
                    <button className="px-6 py-2.5 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white rounded-lg font-bold text-sm shadow-lg transition-all">
                        + Thêm hàng<br />từ file ngoài
                    </button>
                </div>

                {/* Main Form */}
                <div className="bg-white rounded-lg shadow-2xl p-8">
                    <h2 className="text-xl font-bold text-center mb-6">PHIẾU XUẤT KHO</h2>

                    {/* Thông tin chung */}
                    <div className="border-4 border-blue-600 bg-gray-100 p-6 mb-6 rounded">
                        <h3 className="text-base font-bold mb-4">Thông tin chung</h3>

                        <div className="grid grid-cols-2 gap-x-12 gap-y-4">
                            {/* Left Column */}
                            <div className="space-y-4">
                                <div className="flex items-center gap-3">
                                    <label className="w-28 text-sm">Nguồn nhận</label>
                                    <div className="flex-1 relative">
                                        <select className="w-full px-3 py-1.5 border border-blue-600 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 appearance-none bg-white">
                                            <option>Nhà cung cấp A</option>
                                            <option>Nhà cung cấp B</option>
                                            <option>Nhà cung cấp C</option>
                                        </select>
                                        <svg className="absolute right-2 top-1/2 -translate-y-1/2 w-3 h-3 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                                        </svg>
                                    </div>
                                </div>

                                <div className="flex items-center gap-3">
                                    <label className="w-28 text-sm">Mã nguồn</label>
                                    <div className="flex-1 relative">
                                        <select className="w-full px-3 py-1.5 border border-blue-600 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 appearance-none bg-white">
                                            <option>NCCA_9843</option>
                                        </select>
                                        <svg className="absolute right-2 top-1/2 -translate-y-1/2 w-3 h-3 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                                        </svg>
                                    </div>
                                </div>

                                <div className="flex items-center gap-3">
                                    <label className="w-28 text-sm">Số điện thoại</label>
                                    <input
                                        type="text"
                                        defaultValue="0985424661"
                                        className="flex-1 px-3 py-1.5 border border-blue-600 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    />
                                </div>

                                <div className="flex items-start gap-3">
                                    <label className="w-28 text-sm pt-2">Địa chỉ</label>
                                    <textarea
                                        defaultValue="446 Minh Khai, p. Vĩnh Tuy, q2, HCM."
                                        className="flex-1 px-3 py-2 border border-blue-600 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 h-14 resize-none"
                                    ></textarea>
                                </div>
                            </div>

                            {/* Right Column */}
                            <div className="space-y-4">
                                <div className="flex items-center gap-3">
                                    <label className="w-28 text-sm">Mã phiếu</label>
                                    <div className="flex-1 relative">
                                        <input
                                            type="text"
                                            defaultValue="PXK_001"
                                            className="w-full px-3 py-1.5 border border-gray-400 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-200"
                                            readOnly
                                        />
                                    </div>
                                </div>

                                <div className="flex items-start gap-3">
                                    <label className="w-28 text-sm pt-2">Lý do xuất</label>
                                    <textarea
                                        defaultValue="Xuất hàng mới về"
                                        className="flex-1 px-3 py-2 border border-blue-600 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 h-14 resize-none"
                                    ></textarea>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Product Table */}
                    <div className="border-4 border-gray-400 mb-6 overflow-hidden">
                        <table className="w-full">
                            <thead>
                                <tr className="bg-[#0046ff] text-white h-12">
                                    <th className="px-2 text-center font-bold text-sm w-12">STT</th>
                                    <th className="px-2 text-center font-bold text-sm w-40">Tên hàng hóa</th>
                                    <th className="px-2 text-center font-bold text-sm w-24">Mã hàng</th>
                                    <th className="px-2 text-center font-bold text-sm w-20">Đơn vị tính</th>
                                    <th className="px-2 text-center font-bold text-sm w-28">Đơn giá</th>
                                    <th className="px-2 text-center font-bold text-sm w-20">Số lượng</th>
                                    <th className="px-2 text-center font-bold text-sm w-24">Chiết khấu</th>
                                    <th className="px-2 text-center font-bold text-sm w-28">Thành tiền</th>
                                    <th className="px-2 text-center font-bold text-sm w-16">Xóa</th>
                                </tr>
                            </thead>
                            <tbody>
                                {products.map((product) => (
                                    <tr key={product.id} className="border border-gray-400 h-12 hover:bg-gray-50">
                                        <td className="px-2 text-center text-sm border-r border-gray-400">{product.id}</td>
                                        <td className="px-2 text-right text-sm border-r border-gray-400">{product.name}</td>
                                        <td className="px-2 text-center text-sm border-r border-gray-400">{product.code}</td>
                                        <td className="px-2 text-center text-sm border-r border-gray-400">{product.unit}</td>
                                        <td className="px-2 text-right text-sm border-r border-gray-400">{product.price}</td>
                                        <td className="px-2 text-center text-sm border-r border-gray-400">{product.quantity}</td>
                                        <td className="px-2 text-right text-sm border-r border-gray-400">{product.discount}</td>
                                        <td className="px-2 text-right text-sm font-medium border-r border-gray-400">{product.total}</td>
                                        <td className="px-2 text-center border-r border-gray-400">
                                            <button
                                                onClick={() => deleteProduct(product.id)}
                                                className="hover:scale-110 transition-transform"
                                            >
                                                <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
                                                    <path d="M3 6H19M8 6V4C8 3.44772 8.44772 3 9 3H13C13.5523 3 14 3.44772 14 4V6M17 6V18C17 18.5523 16.5523 19 16 19H6C5.44772 19 5 18.5523 5 18V6H17Z" stroke="#f90606" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                                </svg>
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                                <tr className="border border-gray-400 h-12 bg-white">
                                    <td colSpan={7} className="px-2 text-center font-bold text-sm border-r border-gray-400">Tổng</td>
                                    <td className="px-2 text-right font-bold text-sm border-r border-gray-400">{calculateTotal()}</td>
                                    <td className="border-r border-gray-400"></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    {/* Hợp đồng */}
                    <div className="border-4 border-gray-400 bg-gray-100 p-6 mb-6 rounded">
                        <div className="flex items-center gap-4 mb-4">
                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none">
                                <path d="M7 3H17C18.1046 3 19 3.89543 19 5V21L12 17L5 21V5C5 3.89543 5.89543 3 7 3Z" stroke="#000" strokeWidth="2" />
                            </svg>
                            <h3 className="text-sm font-bold">Hợp đồng</h3>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm mb-2">Nội dung</label>
                                <input
                                    type="text"
                                    className="w-full px-3 py-1.5 border border-blue-600 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                                />
                            </div>
                            <div>
                                <label className="block text-sm mb-2">Hình ảnh</label>
                                <div className="flex gap-2">
                                    <input
                                        type="text"
                                        className="flex-1 px-3 py-1.5 border border-blue-600 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    />
                                    <button className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 rounded shadow-lg transition-colors">
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                            <path d="M4 14V16C4 17.1046 4.89543 18 6 18H14C15.1046 18 16 17.1046 16 16V14M10 2V14M10 2L6 6M10 2L14 6" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                        </svg>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Sở cứ */}
                    <div className="border-4 border-gray-400 bg-gray-100 p-6 mb-6 rounded">
                        <div className="flex items-center gap-4 mb-4">
                            <svg width="25" height="25" viewBox="0 0 25 25" fill="none">
                                <rect x="5" y="3" width="14" height="18" rx="1" stroke="#000" strokeWidth="2" />
                                <path d="M9 7H15M9 11H15M9 15H13" stroke="#000" strokeWidth="2" strokeLinecap="round" />
                            </svg>
                            <h3 className="text-sm font-bold">Sở cứ</h3>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm mb-2">Nội dung</label>
                                <input
                                    type="text"
                                    className="w-full px-3 py-1.5 border border-blue-600 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                                />
                            </div>
                            <div>
                                <label className="block text-sm mb-2">Hình ảnh</label>
                                <div className="flex gap-2">
                                    <input
                                        type="text"
                                        className="flex-1 px-3 py-1.5 border border-blue-600 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    />
                                    <button className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 rounded shadow-lg transition-colors">
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                            <path d="M4 14V16C4 17.1046 4.89543 18 6 18H14C15.1046 18 16 17.1046 16 16V14M10 2V14M10 2L6 6M10 2L14 6" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                        </svg>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex justify-end gap-6">
                        <button
                            onClick={() => router.back()}
                            className="px-8 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-lg font-bold text-sm shadow-lg transition-colors"
                        >
                            Hủy
                        </button>
                        <button className="px-8 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold text-sm shadow-lg transition-colors">
                            Lưu
                        </button>
                    </div>
                </div>
            </main>
        </div>
    );
}
