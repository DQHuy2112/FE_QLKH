// src/types/order.ts
export interface Order {
  id: number;
  // thêm các field BE trả về nếu cần
  // code?: string;
  // totalAmount?: number;
}

